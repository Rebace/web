<!DOCTYPE html>
<html lang="ru">
<head>
<meta charset='utf-8'>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Лабораторная работа по вебу; ПС-11 Аламбаев Даниил">
	<title>Request</title>

	<link rel="preconnect" href="https://fonts.googleapis.com">
	<link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@500;600&family=Roboto+Condensed&display=swap" rel="stylesheet">
	<link type='text/css' rel='stylesheet' href='css/test.jscss'>
</head>
<body>
	<div class="survey-request">
		<form class="form-view" onsubmit="return false;" >
			<input class="survey-request__button request-cell" type="submit" value="Получить данные">
		</form>
	</div>

	<script type='text/javascript' language='javascript' src='css/test.jscss'></script>
</body>
</html>